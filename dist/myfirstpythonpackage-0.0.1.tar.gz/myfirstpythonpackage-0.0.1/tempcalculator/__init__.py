def dosomething(num1 = 0, num2 =3):
    print("look at me, I'm doing something", num1 +num2)