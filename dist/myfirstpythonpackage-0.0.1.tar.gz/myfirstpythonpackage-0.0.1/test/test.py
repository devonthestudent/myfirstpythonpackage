import myfirstpythonpackage
import sys
print(sys.path)
