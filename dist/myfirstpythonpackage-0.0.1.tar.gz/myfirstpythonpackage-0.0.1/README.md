this package intends to test the functionality in terms of compiling cython, creating python package, and coding in object-oriented style

```bash
pip install -e .[dev]
```