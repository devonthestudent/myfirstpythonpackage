class Two():
    def __int__(self):
        print("Object two")

    def printself(self):
        print("printselffunction")