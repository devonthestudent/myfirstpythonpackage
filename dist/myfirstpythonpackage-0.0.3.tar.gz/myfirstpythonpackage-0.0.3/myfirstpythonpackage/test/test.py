from myfirstpythonpackage.object_one import One

myone = One()
myone.printself()
print("lalala")