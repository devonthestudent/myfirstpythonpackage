__author__ = 'Chenyu Yang'
from ._cython_code import fib_cpdef