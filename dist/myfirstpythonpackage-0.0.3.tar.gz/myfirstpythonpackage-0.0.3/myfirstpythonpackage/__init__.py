__author__ = 'Chenyu'
from myfirstpythonpackage.object_one import One
from myfirstpythonpackage.object_two import Two